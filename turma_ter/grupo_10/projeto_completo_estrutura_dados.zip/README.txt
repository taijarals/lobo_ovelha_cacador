
PROJETO COMPLETO - ESTRUTURA DE DADOS EM C

Tema:
- Humanos
- Zumbis
- Soldados

Recursos previstos:
- Tabuleiro dinâmico
- Obstáculos
- Movimentação aleatória
- Reprodução
- Combate
- Condição de vitória
- Uso de structs e alocação dinâmica

Compilação:
gcc main.c -o projeto
./projeto
