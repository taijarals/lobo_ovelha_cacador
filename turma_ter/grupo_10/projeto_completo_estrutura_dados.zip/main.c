
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define HUMANO 'H'
#define ZUMBI 'Z'
#define SOLDADO 'S'
#define OBSTACULO '#'
#define VAZIO '.'

void imprimir(char **mapa,int n){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++) printf("%c ",mapa[i][j]);
        printf("\n");
    }
}

int main(){
    int n;
    printf("Tamanho do mapa (>=5): ");
    scanf("%d",&n);

    if(n<5) n=5;

    srand(time(NULL));

    char **mapa = malloc(n*sizeof(char*));
    for(int i=0;i<n;i++){
        mapa[i]=malloc(n*sizeof(char));
        for(int j=0;j<n;j++) mapa[i][j]=VAZIO;
    }

    int humanos=(n*n*12)/100;
    int zumbis=(n*n*12)/100;
    int soldados=(n*n*5)/100;
    int obst=(n*n*10)/100;

    while(humanos){
        int x=rand()%n,y=rand()%n;
        if(mapa[x][y]==VAZIO){mapa[x][y]=HUMANO;humanos--;}
    }
    while(zumbis){
        int x=rand()%n,y=rand()%n;
        if(mapa[x][y]==VAZIO){mapa[x][y]=ZUMBI;zumbis--;}
    }
    while(soldados){
        int x=rand()%n,y=rand()%n;
        if(mapa[x][y]==VAZIO){mapa[x][y]=SOLDADO;soldados--;}
    }
    while(obst){
        int x=rand()%n,y=rand()%n;
        if(mapa[x][y]==VAZIO){mapa[x][y]=OBSTACULO;obst--;}
    }

    printf("\nEstado inicial:\n");
    imprimir(mapa,n);

    for(int i=0;i<n;i++) free(mapa[i]);
    free(mapa);

    return 0;
}
